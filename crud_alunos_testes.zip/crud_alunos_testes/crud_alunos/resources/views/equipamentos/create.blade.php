@extends('crud_template')

@section('content')
<div class="card mt-5">
    <div class="card-header">
        <h2>Cadastro de Equipamentos</h2>
    </div>
    <div class="card-body">
        <div class="row">
            <div class="col">
                @if ($errors->any())
                <div class="alert alert-danger">
                    <strong>Problemas com os dados:</strong>
                    <br>
                    @foreach($errors->all() as $error)
                    <li> {{ $error }}</li>
                    @endforeach
                </div>
                @endif
            </div>
        </div>

        <div class="row">
            <form action="{{ url('equipamentos/novo') }}" method="POST">
                @csrf
                <div class="row">
                    <strong>Item:</strong>
                    <input placeholder="Digite o nome do item" class="form-control mb-3" name="item" type="text" />
                    <strong>Quantidade:</strong>
                    <input placeholder="Digite a quantidade" class="form-control mb-3" name="qtd" type="number" />
                    <strong>Local de destino:</strong>
                    <input placeholder="Digite o local para onde este item irá" class="form-control mb-3" name="local" type="text" />

                    <div class="col">
                        <a class="btn btn-secondary" href="{{ url('/equipamentos') }}">Voltar</a>
                    </div>
                    <div class="col">
                        <button class="btn btn-primary" type="submit">Salvar</button>
                    </div>

                </div>
            </form>
        </div>
    </div>
</div>
@endsection