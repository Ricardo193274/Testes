<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sistema ADS/UPF</title>
</head>

<body>
    <h3> Lista de cidades </h3>
    <ul>
        @foreach($cidades as $cidade)
        <li> {{ $cidade['nome']}} - {{ $cidade['uf']}}</li> 
        @endforeach
    </ul>
    <!-- navegando fazendo um GET para a rota alunos/novo -->
    <a href="{{ url('/cidades/novo') }}">Cadastrar nova</a>
    <br>
    <a href="{{ url('/welcome') }}">Voltar</a>
</body>

</html>