

<?php $__env->startSection('content'); ?>
<div class="card mt-5">
    <div class="card-header">
        <h2>Cadastro de Equipamentos</h2>
    </div>
    <div class="card-body">
        <div class="row">
            <div class="col">
                <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <strong>Problemas com os dados:</strong>
                    <br>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li> <?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <?php endif; ?>
            </div>
        </div>

        <div class="row">
            <form action="<?php echo e(url('equipamentos/novo')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="row">
                    <strong>Item:</strong>
                    <input placeholder="Digite o nome do item" class="form-control mb-3" name="item" type="text" />
                    <strong>Quantidade:</strong>
                    <input placeholder="Digite a quantidade" class="form-control mb-3" name="qtd" type="number" />
                    <strong>Local de destino:</strong>
                    <input placeholder="Digite o local para onde este item irá" class="form-control mb-3" name="local" type="text" />

                    <div class="col">
                        <a class="btn btn-secondary" href="<?php echo e(url('/equipamentos')); ?>">Voltar</a>
                    </div>
                    <div class="col">
                        <button class="btn btn-primary" type="submit">Salvar</button>
                    </div>

                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('crud_template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\kesle\OneDrive\Área de Trabalho\crud_alunos\resources\views/equipamentos/create.blade.php ENDPATH**/ ?>