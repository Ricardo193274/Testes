
<?php $__env->startSection('content'); ?>
<div class="card mt-5">
    <div class="card-header text-center">
        <h2>Login</h2>
    </div>
    <div class="card-body">
        <div class="row">
            <div class="col">
                <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <strong>Problemas com seus dados:</strong>
                    <br>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li> <?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <?php endif; ?>
            </div>
        </div>
        <form action="<?php echo e(url('/login')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <strong>Email</strong>
            <input class="form-control mb-3" type="email" name="email" id="email">
            <strong>Senha</strong>
            <input class="form-control mb-3" type="password" name="password" id="password">
            <div class="text-center">
                <button class="btn btn-primary" type="submit">Entrar</button>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('crud_template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\kesle\OneDrive\Área de Trabalho\crud_alunos\resources\views/login.blade.php ENDPATH**/ ?>