<?php

namespace Tests\Feature;

use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Foundation\Testing\WithFaker;
use Tests\TestCase;

class CrudRouteTest extends TestCase
{
    /**
     * Um exemplo básico de teste de recurso.
     */
    public function test_verificar_rota_da_pagina_inicial_retorna_resposta_bemsucedida(): void
    {
        $response = $this->get('/');
        $response->assertStatus(200);
    }

    public function Test_Verificar_a_Rota_da_Pagina_de_Login_Retorna_sucesso(): void
    {
        $response = $this->get('/login');
        $response->assertStatus(405);
    }

    public function test_verificar_rota_da_pagina_de_welcome_retorna_resposta_bemsucedida(): void
    {
        $response = $this->get('/welcome');
        $response->assertStatus(200);
        $response->assertSee('Sistema ADS UPF');
    }

    public function test_verificar_rota_da_pagina_de_equipamentos_retorna_resposta_bemsucedida(): void
    {
        $response = $this->get('/equipamentos');
        $response->assertSee('Lista de Equipamentos');
        $response->assertStatus(200);
    }

    public function test_verificar_rota_da_pagina_de_edicao_de_equipamentos_retorna_resposta_bemsucedida(): void
    {
        $response = $this->get('/equipamentos/editar');
        $response->assertStatus(405);
    }

    public function test_verificar_rota_da_pagina_de_criacao_de_equipamentos_retorna_resposta_bemsucedida(): void
    {
        $response = $this->get('/equipamentos/novo');
        $response->assertSee('Cadastro de Equipamentos');
        $response->assertStatus(200);
    }
}
