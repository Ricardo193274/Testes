<?php

namespace Tests\Feature;

use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Foundation\Testing\WithFaker;
use Tests\TestCase;
use App\Models\User;
use Illuminate\Support\Facades\Auth;


class LoginTest extends TestCase
{

    public function test_exemplo(): void
    {
        $response = $this->get('/');

        $response->assertStatus(200);
    }

    public function testSucessoAutenticação(): void
    { 
        $response = $this->post('/login', [
            'email' => 'test@example.com',
            'password' => 'password',
        ]);
    
        $response->assertStatus(302)
            ->assertRedirect('welcome');
    
        $this->assertTrue(Auth::check());
    }
    
    public function testFalhaAutenticação(): void
    {
        $response = $this->post('/login', [
            'email' => 'invalid@example.com',
            'password' => 'wrong_password',
        ]);
    
        $response->assertStatus(302)
            ->assertRedirect('')
            ->assertSessionHasErrors(['email']);
    
        $this->assertFalse(Auth::check());
    }
    
    public function testLogout(): void
    {
        $user = User::factory()->create();
    
        $this->actingAs($user); // Loga o usuário antes do teste.
    
        $response = $this->post('/logout');
    
        $response->assertStatus(302) // Verifica se a resposta é um redirecionamento após o logout.
            ->assertRedirect('/');
    
        $this->assertFalse(Auth::check()); // Verifica se o usuário não está autenticado após o logout.
    }
}
