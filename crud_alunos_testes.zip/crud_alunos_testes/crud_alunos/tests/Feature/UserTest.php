<?php

namespace Tests\Feature;

use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Foundation\Testing\WithFaker;
use Tests\TestCase;
use App\Models\Equipamento;
use Database\Factories\EquipamentoFactory;
use App\Http\Controllers\EquipamentosController;


class UserTest extends TestCase
{
    
    public function test_exemplo(): void
    {
        $response = $this->get('/');

        $response->assertStatus(200);
    }

    public function test_cria_equipamento():void
    {
    $dadosProduto = [
        'item' => 'Equipamento Atualizado',
        'local' => 'Sala de Atualização',
    ];

    $response = $this->post('/equipamentos/novo', $dadosProduto);

    $this->assertDatabaseHas('equipamentos', $dadosProduto);
    $response->assertStatus(302);
    }

    public function testIndex(): void
{
    $response = $this->get('/equipamentos');

    $response->assertStatus(200)
        ->assertViewIs('equipamentos.index')
        ->assertSee('Lista de Equipamentos'); 
}

public function testCriar(): void
{
    $response = $this->get('/equipamentos/novo');

    $response->assertStatus(200)
        ->assertViewIs('equipamentos.create');
}

public function testGuardar(): void
{
    $data = [
        'item' => 'Equipamento de Teste',
        'qtd' => 5,
        'local' => 'Sala de Testes',
    ];

    $response = $this->post('/equipamentos/novo', $data);

    $response->assertStatus(302) 
        ->assertRedirect('/equipamentos')
        ->assertSessionHas('success', 'Equipamento salvo com sucesso!');

    $this->assertDatabaseHas('equipamentos', $data);
}

public function testEditar(): void
{
    $equipamento = Equipamento::factory()->create();

    $response = $this->get("/equipamentos/editar/{$equipamento->id}");

    $response->assertStatus(200)
        ->assertViewIs('equipamentos.edit');
}

public function testAtualizar(): void
{
    $equipamento = Equipamento::factory()->create();

    $data = [
        'item' => 'Equipamento Atualizado',
        'qtd' => 3,
        'local' => 'Sala de Atualização',
    ];

    $response = $this->put("/equipamentos/editar/{$equipamento->id}", $data);

    $response->assertStatus(302) 
        ->assertRedirect('/equipamentos')
        ->assertSessionHas('success', 'Equipamento editado com sucesso!');

    $this->assertDatabaseHas('equipamentos', $data); 
}

public function testDeletar(): void
{
    $equipamento = Equipamento::factory()->create();

    $response = $this->delete("/equipamentos/delete/{$equipamento->id}");

    $response->assertStatus(302) 
        ->assertRedirect('/equipamentos');

    $this->assertDatabaseMissing('equipamentos', ['id' => $equipamento->id]); 
}

}


