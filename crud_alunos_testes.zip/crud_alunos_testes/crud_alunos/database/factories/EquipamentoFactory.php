<?php

namespace Database\Factories;
use App\Models\Equipamento;
use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\Equipamento>
 */
class EquipamentoFactory extends Factory
{
    protected $model = Equipamento::class;

    public function definition()
    {
        return [
            'item' => $this->faker->word,
            'qtd' => $this->faker->randomNumber(),
            'local' => $this->faker->word,
        ];
    }
}
