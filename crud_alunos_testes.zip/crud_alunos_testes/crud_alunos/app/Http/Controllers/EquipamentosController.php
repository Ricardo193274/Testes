<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use App\Models\Equipamento;
use Illuminate\Support\Facades\DB;

class EquipamentosController extends Controller
{
    public function index()
    {

        $equipamentos = DB::table('equipamentos')->orderBy('item', 'asc')->get();
        $equipamentos = json_decode($equipamentos, true);
        return view(
            'equipamentos.index',
            ['equipamentos' => $equipamentos]
        ); //select * from equipamentos
    }

    //função que irá retornar a tela do form
    public function create()
    {
        return view("equipamentos.create");
    }

    public function store(Request $request)
    {
        $request->validate([
            'item' => 'required|min:2|max:50',
            'local' => 'required|min:2|max:50'
        ]);

        Equipamento::create([
            'item' => $request->item,
            'qtd' => $request->qtd,
            'local' => $request->local
        ]);
        return redirect('/equipamentos')->with('success', 'Equipamento salvo com sucesso!');
    }

    public function edit($id)
    {
        $equipamento = Equipamento::find($id);
        return view('equipamentos.edit', ['equipamento' => $equipamento]);
    }
    public function update(Request $request)
    {
        $request->validate([
            'item' => 'required|min:2|max:50',
            'local' => 'required|min:2|max:50'
        ]);

        $equipamento = Equipamento::find($request->id);
        $equipamento->update([
            'item' => $request->item,
            'qtd' => $request->qtd,
            'local' => $request->local
        ]);
        return redirect('/equipamentos')->with('success', 'Equipamento editado com sucesso!');
    }

    public function destroy($id)
    {
        $equipamento = Equipamento::find($id);
        $equipamento->delete();
        return redirect('/equipamentos');
    }
}
