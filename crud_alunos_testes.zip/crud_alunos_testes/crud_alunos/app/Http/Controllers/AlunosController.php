<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use App\Models\Aluno;
use Illuminate\Support\Facades\DB;

class AlunosController extends Controller
{
    public function index() {

        $alunos = DB::table('alunos')->orderBy('nome', 'asc')->get();
        $alunos = json_decode($alunos, true);
        return view('alunos.index', 
        ['alunos' => $alunos]); //select * from alunos
    }
    
    //função que irá retornar a tela do form
    public function create() {
        return view("alunos.create");
    }

    public function store(Request $request) {
        //dd($request->all());

        $request->validate([
            'nome' => 'required|min:2|max:50',
            'email' => 'email:rfc,dns'
        ]);
        
        Aluno::create([
            'nome' => $request->nome,
            'idade' => $request->idade,
            'email' => $request->email
        ]);
        return redirect('/alunos')->with('success', 'Aluno salvo com sucesso!');
    }
}
