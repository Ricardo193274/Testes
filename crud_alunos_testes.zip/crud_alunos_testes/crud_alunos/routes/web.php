<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AlunosController;
use App\Http\Controllers\LoginController;
use App\Http\Controllers\EquipamentosController;

Route::get('/', function () {
    return view('login');
});

Route::get('/welcome', function () {
    return view('welcome');
});

Route::post('/login', [LoginController::class, 'authenticate']);
Route::get('/logout', [LoginController::class, 'logout']);
Route::post('/logout', [LoginController::class, 'logout']);

Route::get('/alunos', [AlunosController::class, 'index'])->middleware('auth.basic');
Route::get('/alunos/novo', [AlunosController::class, 'create'])->middleware('auth.basic');
Route::post('/alunos/novo', [AlunosController::class, 'store'])->middleware('auth.basic');

Route::get('/alunos/delete/{id}', [AlunosController::class, 'destroy'])->middleware('auth.basic');
Route::get('/alunos/editar/{id}', [AlunosController::class, 'edit'])->middleware('auth.basic');
Route::post('/alunos/editar/', [AlunosController::class, 'update'])->middleware('auth.basic');

Route::get('/equipamentos', [EquipamentosController::class, 'index']);
Route::get('/equipamentos/novo', [EquipamentosController::class, 'create']);
Route::post('/equipamentos/novo', [EquipamentosController::class, 'store']);

Route::get('/equipamentos/delete/{id}', [EquipamentosController::class, 'destroy']);
Route::delete('/equipamentos/delete/{id}', [EquipamentosController::class, 'destroy']);
Route::get('/equipamentos/editar/{id}', [EquipamentosController::class, 'edit']);
Route::post('/equipamentos/editar/', [EquipamentosController::class, 'update']);
Route::put('/equipamentos/editar/{id}', [EquipamentosController::class, 'update']);

Route::get('/cidades', [CidadesController::class, 'index']);
Route::get('/cidades/novo', [CidadesController::class, 'create']);
Route::post('/cidades/novo', [CidadesController::class, 'store']);
